// features/order/orderCartSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

// Kiểu dữ liệu sản phẩm trong giỏ
interface CartProduct {
  id: string;
  name: string;
  quantity: number;
  price: number;
  [key: string]: any; // Có thể có các field mở rộng khác như image, category,...
}

interface CartState {
  products: CartProduct[];
}

const initialState: CartState = {
  products: [],
};

const orderCartSlice = createSlice({
  name: 'orderCart',
  initialState,
  reducers: {
    addProductToCart(state, action: PayloadAction<CartProduct>) {
      const existingProduct = state.products.find(p => p.id === action.payload.id);
      if (existingProduct) {
        existingProduct.quantity += action.payload.quantity;
      } else {
        state.products.push(action.payload);
      }
    },
    removeProductFromCart(state, action: PayloadAction<string>) {
      state.products = state.products.filter(p => p.id !== action.payload);
    },
    updateProductQuantity(state, action: PayloadAction<{ id: string; quantity: number }>) {
      const product = state.products.find(p => p.id === action.payload.id);
      if (product) {
        product.quantity = action.payload.quantity;
      }
    },
    clearCart(state) {
      state.products = [];
    },
  },
});

export const { addProductToCart, removeProductFromCart, updateProductQuantity, clearCart } = orderCartSlice.actions;
export default orderCartSlice.reducer;
