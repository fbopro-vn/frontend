'use client'
import { useRef, useState } from "react";
import { useOrderContext } from "@/app/context/OrderContext";
import {
  Box,
  TextField,
  Typography,
  Button,
  Select,
  MenuItem,
  Switch
} from "@mui/material";
import { NumericFormat } from "react-number-format";
import { SelectChangeEvent } from "@mui/material";
import { toast } from "react-toastify";
import { mutate } from "swr";
import "@/app/components/css_animation/loaderOther.css";
import useCartData from "@/app/hooks/useCartData";

const UnderInfo = () => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const depositInputRef = useRef<HTMLInputElement | null>(null);
  const {
    orders,
    isCheckoutMode,
    updatePaidPayment,
    getActiveOrderDeposit,
    getActiveOrderPaidPayment,
    updateOrderField,
    getActiveOrderPaymentMethod,
    getActiveOrderPaymentStatus,
    totalNeedPay,
    getFilteredOrder,
    removeOrder,
    activeOrderId,
    validateOrderErrors,
    updateOrderInCart,
    // addSpecificOrder,
    updateActiveOrderSeller
  } = useOrderContext();
  const label = { inputProps: { "aria-label": "Switch demo" } };
  const [isLoading, setIsLoading] = useState<boolean>(false);
  // OK
  // const handleOrderSubmit = async (): Promise<void> => {
  //   const orderData = getFilteredOrder(); // Lấy dữ liệu cần gửi
  //   if (!validateOrderErrors()) {
  //     return;
  //   }
  
  //   console.log("Dữ liệu gửi đi", orderData);
  //   setIsLoading(true); // Bật spinner
  
  //   // Lấy access_token từ localStorage hoặc sessionStorage
  //   const accessToken = localStorage.getItem('access_token');
  //   if (!accessToken) {
  //     toast.error("❌ Không tìm thấy access token!");
  //     setIsLoading(false);
  //     return;
  //   }
  
  //   if (activeOrderId) {
  //     try {
  //       const response = await fetch('http://api.sdc.com:8000/v1/orders', {
  //         method: 'POST',
  //         headers: {
  //           'Accept': 'application/json, text/plain, */*',
  //           'Content-Type': 'application/json',
  //           'Authorization': `Bearer ${accessToken}`, // Thêm token vào header
  //         },
  //         body: JSON.stringify(orderData)
  //       });
  
  //       const resData = await response.json();
  //       console.log(">>>> check ResData Đặt hàng", resData);
  //       if (resData) {
  //         removeOrder(activeOrderId);
  //         updateActiveOrderSeller({ id: "", fullname: "" });
  //           // Delay nếu backend xử lý chậm
  //       await new Promise(resolve => setTimeout(resolve, 2000));

  //       // Refresh lại dữ liệu giỏ hàng (fetch lại từ API giỏ hàng)
  //       mutate('http://api.sdc.com:8000/v1/orders/cart'); // reload dữ liệu cache
  //       }
  //     } catch (error) {
  //       toast.error("❌ Lỗi khi đặt hàng!");
  //       console.error("Lỗi khi đặt hàng:", error);
  //     } finally {
  //       setIsLoading(false);
  //     }
  //   }
  // };
  
   const handleOrderSubmit = async (): Promise<void> => {
    const orderData = getFilteredOrder(); // Lấy dữ liệu cần gửi
    if (!validateOrderErrors()) {
      return;
    }
  
    console.log("Dữ liệu gửi đi", orderData);
    setIsLoading(true); // Bật spinner
  
    // Lấy access_token từ localStorage hoặc sessionStorage
    const accessToken = localStorage.getItem('access_token');
    if (!accessToken) {
      toast.error("❌ Không tìm thấy access token!");
      setIsLoading(false);
      return;
    }
  
    if (activeOrderId) {
      try {
        const response = await fetch('http://api.sdc.com:8000/v1/orders', {
          method: 'POST',
          headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`, // Thêm token vào header
          },
          body: JSON.stringify(orderData)
        });
  
        const resData = await response.json();
        console.log(">>>> check ResData Đặt hàng", resData);
        if (resData) {
          removeOrder(activeOrderId);
          updateActiveOrderSeller({ id: "", fullname: "" });
            // Delay nếu backend xử lý chậm
        await new Promise(resolve => setTimeout(resolve, 2000));

        // Refresh lại dữ liệu giỏ hàng (fetch lại từ API giỏ hàng)
        mutate('http://api.sdc.com:8000/v1/orders/cart'); // reload dữ liệu cache
        }
      } catch (error) {
        toast.error("❌ Lỗi khi đặt hàng!");
        console.error("Lỗi khi đặt hàng:", error);
      } finally {
        setIsLoading(false);
      }
    }
  };
  

  // Tạm thời không sử dụng chức năng này
  // const handlerOrderPay = async (): Promise<void> => {

  //   if (!validateOrderErrors()) {
  //     return;
  //   }
  //   console.log(">>>>check tiền dã thanh toán", getActiveOrderPaidPayment())
  //   setIsLoading(true) // Thêm spiner
  //   // Dữ liệu gửi qua
  //   if (activeOrderId) {
  //     try {
  //       const response = await fetch(`http://192.168.1.203:8000/qlybanhang/donhang/paid_invoice/${activeOrderId}?paid_payment=${getActiveOrderPaidPayment()}`, {
  //         method: 'POST',
  //         headers: {
  //           'Accept': 'application/json, text/plain, */*',
  //           'Content-Type': 'application/json'
  //         }
  //       });

  //       const resData = await response.json();
  //       console.log(">>>> check REsdata", resData)
  //       if (resData) {
  //         removeOrder(activeOrderId);
  //         mutate("http://192.168.1.203:8000/qlybanhang")
  //         // Chỉ cần mutate lại là thành công
  //         // mutate("http://192.168.1.203:8000/qlybanhang", async () => {
  //         //   console.log("Dữ liệu hiện tại trước khi mutate:", cartData); // Kiểm tra dữ liệu cũ
  //         //   // Có thể fetch lại dữ liệu nếu muốn
  //         //   const res = await fetch("http://192.168.1.203:8000/qlybanhang");
  //         //   const newData = await res.json();
  //         //   console.log("Dữ liệu sau khi fetch lại:", newData); // Kiểm tra dữ liệu mới
  //         //   return newData;
  //         // });

  //       }
  //     } catch (error) {
  //       toast.error("❌ Lỗi khi thanh toán!");
  //       console.error("Lỗi khi thanh toán:", error);
  //     } finally { setIsLoading(false) } // Thêm spiner}
  //   }
  // }

  // Lưu 
  const handleUpdate = async (): Promise<void> => {
    if (!activeOrderId) return;

    setIsLoading(true);

    try {
      // 🟢 Lấy dữ liệu đơn hàng đầy đủ trước khi gửi xuống backend
      const formattedOrder = await updateOrderInCart(activeOrderId);

      if (!formattedOrder) {
        setIsLoading(false);
        return;
      }

      // 🟢 Gửi dữ liệu xuống backend
      const response = await fetch(
        `http://192.168.1.203:8000/qlybanhang/donhang/add-new-item/${activeOrderId}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify([formattedOrder]), // ✅ Gửi toàn bộ thông tin
        }
      );

      const resData = await response.json();
      console.log("✅ Kết quả sau khi gửi dữ liệu:", resData);

      if (resData.message === "success") {
        toast.success("✅ Đã lưu đơn hàng thành công!");
      } else {
        toast.error("❌ Lỗi khi lưu đơn hàng!");
      }
    } catch (error) {
      console.error("❌ Lỗi khi gửi dữ liệu xuống backend:", error);
      toast.error("❌ Không thể lưu đơn hàng!");
    } finally {
      setIsLoading(false);
    }
  };


  return (
    // Goc
    <Box
    sx={{
      width: "100%",
      maxWidth: "600px",
      minHeight: "250px",
      mt: "10px",
      ml: "30px",
      p: "20px",
      borderRadius: "10px",
      boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
      backgroundColor: "white",
    }}
    >
    {/* Hàng 1: Khách thanh toán & Hình thức thanh toán */}
    <Box
      sx={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: "20px",
        mb: 2,
      }}
    >
      {/* Nếu là Checkout Mode (Thanh toán đơn hàng) */}
      {isCheckoutMode && (
        <Box sx={{ flex: 1 }}>
          <Typography variant="body1" fontWeight="bold" mb={1}>
            Khách thanh toán
          </Typography>
          <NumericFormat
            // value={getActiveOrderPaidPayment()} Later cho thanh toasn
            onValueChange={(valueObj) => {
              updatePaidPayment(Number(valueObj.value) || 0);
            }}
            onFocus={() => {
              // ✅ Khi focus thì select toàn bộ
              setTimeout(() => {
                if (inputRef.current) inputRef.current.select();
              }, 0);
            }}
            customInput={TextField}
            getInputRef={(el: HTMLElement | null) => {
              inputRef.current = el instanceof HTMLInputElement ? el : el?.querySelector('input') ?? null;
            }}
            thousandSeparator="."
            decimalSeparator=","
            valueIsNumericString
            suffix=" VND"
            variant="outlined"
            fullWidth
            sx={{
              height: "40px",
              "& .MuiOutlinedInput-root": {
                height: "40px",
                "& input": {
                  padding: "8px 12px",
                },
              },
            }}
          />
        </Box>
    
    
    
      )}
    
      {/* Nếu là Đặt hàng (Cọc) */}
      {!isCheckoutMode && (
        <Box sx={{ flex: 1 }}>
          <Typography variant="body1" fontWeight="bold" mb={1}>
            Khách thanh toán (cọc)
          </Typography>
          <NumericFormat
            value={getActiveOrderDeposit()}
            onValueChange={(values) =>
              updateOrderField("deposit", Number(values.value) || 0)
            }
            onFocus={() => {
              setTimeout(() => {
                depositInputRef.current?.select();
              }, 0);
            }}
            getInputRef={(el: HTMLElement | null) => {
              depositInputRef.current =
                el instanceof HTMLInputElement
                  ? el
                  : el?.querySelector("input") ?? null;
            }}
            customInput={TextField}
            thousandSeparator="."
            decimalSeparator=","
            valueIsNumericString
            suffix=" VND"
            variant="outlined"
            fullWidth
            sx={{
              height: "40px",
              "& .MuiOutlinedInput-root": {
                height: "40px",
                "& input": {
                  padding: "8px 12px",
                },
              },
            }}
          />
        </Box>
      )}
    
      {/* Hình thức thanh toán */}
      <Box sx={{ flex: 1 }}>
        <Typography variant="body1" fontWeight="bold" mb={1}>
          Hình thức thanh toán
        </Typography>
        <Select
          sx={{
            width: "100%",
            height: "40px",
            "& .MuiSelect-select": {
              padding: "8px",
              minHeight: "32px",
              display: "flex",
              alignItems: "center",
            },
          }}
          key={getActiveOrderPaymentMethod()}
          value={getActiveOrderPaymentMethod()}
          onChange={(event: SelectChangeEvent<string>) =>
            updateOrderField("paymentMethod", event.target.value)
          }
        >
          <MenuItem value="Chuyển khoản cá nhân">Chuyển khoản cá nhân</MenuItem>
          <MenuItem value="Chuyển khoản công ty">Chuyển khoản công ty</MenuItem>
          <MenuItem value="Tiền mặt">Tiền mặt</MenuItem>
        </Select>
      </Box>
    </Box>
    
    {/* Hàng 2: Trạng thái thanh toán */}
    <Box sx={{ width: "100%" }}>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
        <Typography variant="body1" fontWeight="bold">
          Thu hộ (COD)
        </Typography>
        <Switch
          checked={getActiveOrderPaymentStatus()}
          onChange={() => {
            updateOrderField("paymentStatus", !getActiveOrderPaymentStatus());
          }}
        />
      </Box>
    
      <Box sx={{ color: "green" }}>
        <Typography variant="body1" fontWeight="bold">
          Trạng Thái Thanh Toán:
        </Typography>
    
        {/* Trạng Thái Thanh Toán*/}
        {isCheckoutMode && (
          <Typography
            variant="body1"
            fontWeight="bold"
            sx={{
              color:
                totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment() === 0
                  ? "green"
                  : getActiveOrderPaymentStatus()
                    ? "green"
                    : "error.main",
            }}
          >
            {totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment() === 0
              ? "Thu tiền Khách: 0 VND"
              : getActiveOrderPaymentStatus()
                ? `Thu tiền Khách: ${(totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment()).toLocaleString()} VND`
                : `Ghi công nợ: ${(totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment()).toLocaleString()} VND`}
          </Typography>)}
        {!isCheckoutMode && (
          <Typography
            variant="body1"
            fontWeight="bold"
            sx={{
              color:
                totalNeedPay - getActiveOrderDeposit() === 0
                  ? "green"
                  : getActiveOrderPaymentStatus()
                    ? "green"
                    : "error.main",
            }}
          >
            {totalNeedPay - getActiveOrderDeposit() === 0
              ? "Thu tiền Khách: 0 VND"
              : getActiveOrderPaymentStatus()
                ? `Thu tiền Khách: ${(totalNeedPay - getActiveOrderDeposit()).toLocaleString()} VND`
                : `Ghi công nợ: ${(totalNeedPay - getActiveOrderDeposit()).toLocaleString()} VND`}
          </Typography>
        )}
      </Box>
    </Box>
    
    {/* Nút hành động */}
    <Box
      sx={{
        display: "flex",
        justifyContent: "end",
        alignItems: "center",
        paddingRight: "14px",
        mt: "7px",
      }}
    >
      <Box sx={{ display: "flex", gap: "40px" }}>
        {/* Nếu là Checkout Mode (Thanh toán đơn hàng) */}
        {isCheckoutMode && (
          <>
            <Button
              variant="contained"
              sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
            >
              In
            </Button>
            <Button
              variant="contained"
              sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
              // onClick={handlerOrderPay} // Tạm thời
            >
              Thanh Toán
            </Button>
            <Button
              variant="contained"
              sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
              onClick={() => handleUpdate()}
            >
              Lưu
            </Button>
          </>
        )}
    
        {/* Nếu là Đặt hàng (Cọc) */}
        {!isCheckoutMode && (
          <>
            <Button
              variant="contained"
              sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
            >
              In
            </Button>
            <Button
              variant="contained"
              sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
              onClick={() => handleOrderSubmit()}
            >
              Đặt hàng
            </Button>
          </>
        )}
      </Box>
    </Box>
    {isLoading && (
      <Box
        sx={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100vw",
          height: "100vh",
          backgroundColor: "rgba(0,0,0,0.3)", // nền mờ
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          zIndex: 9999,
        }}
      >
        <Box className="loader" />
      </Box>
    )}
    
    
    </Box>

    // Loader

    // v2
  );
};

export default UnderInfo;


// <Box
// sx={{
//   width: "100%",
//   maxWidth: "600px",
//   minHeight: "250px",
//   mt: "10px",
//   ml: "30px",
//   p: "20px",
//   borderRadius: "10px",
//   boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
//   backgroundColor: "white",
// }}
// >
// {/* Hàng 1: Khách thanh toán & Hình thức thanh toán */}
// <Box
//   sx={{
//     display: "flex",
//     justifyContent: "space-between",
//     alignItems: "center",
//     gap: "20px",
//     mb: 2,
//   }}
// >
//   {/* Nếu là Checkout Mode (Thanh toán đơn hàng) */}
//   {isCheckoutMode && (
//     <Box sx={{ flex: 1 }}>
//       <Typography variant="body1" fontWeight="bold" mb={1}>
//         Khách thanh toán
//       </Typography>
//       <NumericFormat
//         value={getActiveOrderPaidPayment()}
//         onValueChange={(valueObj) => {
//           updatePaidPayment(Number(valueObj.value) || 0);
//         }}
//         onFocus={() => {
//           // ✅ Khi focus thì select toàn bộ
//           setTimeout(() => {
//             if (inputRef.current) inputRef.current.select();
//           }, 0);
//         }}
//         customInput={TextField}
//         getInputRef={(el: HTMLElement | null) => {
//           inputRef.current = el instanceof HTMLInputElement ? el : el?.querySelector('input') ?? null;
//         }}
//         thousandSeparator="."
//         decimalSeparator=","
//         valueIsNumericString
//         suffix=" VND"
//         variant="outlined"
//         fullWidth
//         sx={{
//           height: "40px",
//           "& .MuiOutlinedInput-root": {
//             height: "40px",
//             "& input": {
//               padding: "8px 12px",
//             },
//           },
//         }}
//       />
//     </Box>



//   )}

//   {/* Nếu là Đặt hàng (Cọc) */}
//   {!isCheckoutMode && (
//     <Box sx={{ flex: 1 }}>
//       <Typography variant="body1" fontWeight="bold" mb={1}>
//         Khách thanh toán (cọc)
//       </Typography>
//       <NumericFormat
//         value={getActiveOrderDeposit()}
//         onValueChange={(values) =>
//           updateOrderField("deposit", Number(values.value) || 0)
//         }
//         onFocus={() => {
//           setTimeout(() => {
//             depositInputRef.current?.select();
//           }, 0);
//         }}
//         getInputRef={(el: HTMLElement | null) => {
//           depositInputRef.current =
//             el instanceof HTMLInputElement
//               ? el
//               : el?.querySelector("input") ?? null;
//         }}
//         customInput={TextField}
//         thousandSeparator="."
//         decimalSeparator=","
//         valueIsNumericString
//         suffix=" VND"
//         variant="outlined"
//         fullWidth
//         sx={{
//           height: "40px",
//           "& .MuiOutlinedInput-root": {
//             height: "40px",
//             "& input": {
//               padding: "8px 12px",
//             },
//           },
//         }}
//       />
//     </Box>
//   )}

//   {/* Hình thức thanh toán */}
//   <Box sx={{ flex: 1 }}>
//     <Typography variant="body1" fontWeight="bold" mb={1}>
//       Hình thức thanh toán
//     </Typography>
//     <Select
//       sx={{
//         width: "100%",
//         height: "40px",
//         "& .MuiSelect-select": {
//           padding: "8px",
//           minHeight: "32px",
//           display: "flex",
//           alignItems: "center",
//         },
//       }}
//       key={getActiveOrderPaymentMethod()}
//       value={getActiveOrderPaymentMethod()}
//       onChange={(event: SelectChangeEvent<string>) =>
//         updateOrderField("paymentMethod", event.target.value)
//       }
//     >
//       <MenuItem value="Chuyển khoản cá nhân">Chuyển khoản cá nhân</MenuItem>
//       <MenuItem value="Chuyển khoản công ty">Chuyển khoản công ty</MenuItem>
//       <MenuItem value="Tiền mặt">Tiền mặt</MenuItem>
//     </Select>
//   </Box>
// </Box>

// {/* Hàng 2: Trạng thái thanh toán */}
// <Box sx={{ width: "100%" }}>
//   <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//     <Typography variant="body1" fontWeight="bold">
//       Thu hộ (COD)
//     </Typography>
//     <Switch
//       checked={getActiveOrderPaymentStatus()}
//       onChange={() => {
//         updateOrderField("paymentStatus", !getActiveOrderPaymentStatus());
//       }}
//     />
//   </Box>

//   <Box sx={{ color: "green" }}>
//     <Typography variant="body1" fontWeight="bold">
//       Trạng Thái Thanh Toán:
//     </Typography>

//     {/* Trạng Thái Thanh Toán*/}
//     {isCheckoutMode && (
//       <Typography
//         variant="body1"
//         fontWeight="bold"
//         sx={{
//           color:
//             totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment() === 0
//               ? "green"
//               : getActiveOrderPaymentStatus()
//                 ? "green"
//                 : "error.main",
//         }}
//       >
//         {totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment() === 0
//           ? "Thu tiền Khách: 0 VND"
//           : getActiveOrderPaymentStatus()
//             ? `Thu tiền Khách: ${(totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment()).toLocaleString()} VND`
//             : `Ghi công nợ: ${(totalNeedPay - getActiveOrderDeposit() - getActiveOrderPaidPayment()).toLocaleString()} VND`}
//       </Typography>)}
//     {!isCheckoutMode && (
//       <Typography
//         variant="body1"
//         fontWeight="bold"
//         sx={{
//           color:
//             totalNeedPay - getActiveOrderDeposit() === 0
//               ? "green"
//               : getActiveOrderPaymentStatus()
//                 ? "green"
//                 : "error.main",
//         }}
//       >
//         {totalNeedPay - getActiveOrderDeposit() === 0
//           ? "Thu tiền Khách: 0 VND"
//           : getActiveOrderPaymentStatus()
//             ? `Thu tiền Khách: ${(totalNeedPay - getActiveOrderDeposit()).toLocaleString()} VND`
//             : `Ghi công nợ: ${(totalNeedPay - getActiveOrderDeposit()).toLocaleString()} VND`}
//       </Typography>
//     )}
//   </Box>
// </Box>

// {/* Nút hành động */}
// <Box
//   sx={{
//     display: "flex",
//     justifyContent: "end",
//     alignItems: "center",
//     paddingRight: "14px",
//     mt: "7px",
//   }}
// >
//   <Box sx={{ display: "flex", gap: "40px" }}>
//     {/* Nếu là Checkout Mode (Thanh toán đơn hàng) */}
//     {isCheckoutMode && (
//       <>
//         <Button
//           variant="contained"
//           sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
//         >
//           In
//         </Button>
//         <Button
//           variant="contained"
//           sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
//           onClick={handlerOrderPay} // Tạm thời
//         >
//           Thanh Toán
//         </Button>
//         <Button
//           variant="contained"
//           sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
//           onClick={() => handlerUpdate()}
//         >
//           Lưu
//         </Button>
//       </>
//     )}

//     {/* Nếu là Đặt hàng (Cọc) */}
//     {!isCheckoutMode && (
//       <>
//         <Button
//           variant="contained"
//           sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
//         >
//           In
//         </Button>
//         <Button
//           variant="contained"
//           sx={{ backgroundColor: "#8DB883", fontSize: "16px", fontWeight: "bold", width: "150px", color: 'white' }}
//           onClick={() => handleOrderSubmit()}
//         >
//           Đặt hàng
//         </Button>
//       </>
//     )}
//   </Box>
// </Box>
// {isLoading && (
//   <Box
//     sx={{
//       position: "fixed",
//       top: 0,
//       left: 0,
//       width: "100vw",
//       height: "100vh",
//       backgroundColor: "rgba(0,0,0,0.3)", // nền mờ
//       display: "flex",
//       justifyContent: "center",
//       alignItems: "center",
//       zIndex: 9999,
//     }}
//   >
//     <Box className="loader" />
//   </Box>
// )}


// </Box>