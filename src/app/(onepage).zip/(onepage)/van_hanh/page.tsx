import Box from "@mui/material/Box"

const Trello = () => {
    return (
        <Box>
            Trello page
        </Box>
    )
}

export default Trello